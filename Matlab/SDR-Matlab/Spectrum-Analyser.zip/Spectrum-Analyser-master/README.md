# Spectrum-Analyser

SDR_Spectrum_Analyser.m is the original code file.
SDR_Spectrum_Analyser.fig is the user interface file.

Software requirement:
1. Matlab 2012b above.
2. Support package for SDR-RTL usb receiver.

Download: https://www.mathworks.com/hardware-support/rtl-sdr.html

Haedware requirement:
RTL-SDR USB receiver

To run the program, please open SDR_Spectrum_Analyser.m. Editor->Run
