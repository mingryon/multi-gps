# GNSS-Software-Defined-Radio
GPS software-defined receiver (SDR) course project which acquires and tracks a single GPS L1 C/A signal. Furthermore, the navigation solution will be found using the last recorded
pseudorange measurments at SV transmission. The solution will be given in ECEF coordinates. Note, .bin file is too large to upload to GitHub so I've left it out of this project repository.
