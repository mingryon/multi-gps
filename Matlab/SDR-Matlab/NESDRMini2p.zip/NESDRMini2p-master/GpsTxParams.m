global GpsRx GpsTx

GpsTx.L1Freq_Hz = 1575.42e6 ;
GpsTx.L2Freq_Hz = 1227.6e6 ;
GpsTx.L1Bandwidth_Hz = 1.023e6 ;

