# NB-IoT-base-station-SDR-receiver-filter-design
Designing an FIR digital filter using MATLAB filter design app for a NB-IoT software defined radio (SDR) base station Receiver.
