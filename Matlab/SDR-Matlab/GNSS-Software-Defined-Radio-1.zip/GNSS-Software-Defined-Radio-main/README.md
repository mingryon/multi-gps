# GNSS-Software-Defined-Radio
GPS software-defined receiver (SDR) course project which acquires and tracks Global Positioning System (GPS) L1 C/A signals. Also, the navigation solution given in Earth-Centered, Earth-Fixed (ECEF) coordinates was determined using the last recorded pseudorange measurments from the transmitting satellite vehicle (SV).
