function [X] = SOMP(Y, A, K)
% SOMP function
% Y: recieved signal
% A: dictionary matrix
% K: number of signals

end

