for dir in {5..10}
do 
    mkdir pwr$dir
done
