# Anti-jamming-Channel-Allocation-in-UAV-enabled-Edge-Computing-A-Stackelberg-Game-Approach
source code of the paper "Anti-jamming Channel Allocation in UAV-enabled Edge Computing: A Stackelberg Game Approach" published in MSN 2022
